<?php
/**
 * 
 * Include all important files here
 */
include_once "app/db.php";
include_once "app/functions.php";